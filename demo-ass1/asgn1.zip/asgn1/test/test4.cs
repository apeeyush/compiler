using System;
namespace Program
{
	class Checkcomments
	{
		static void Main(string[] args)
		{
			/*my first program in C#*/
			//This is the second comment
			int a = 10;
			Console.WriteLine("a: {0}", a);
			/*Third comment
			This goes multiline*/
			int b = 30;
			//Last comment
    }

	}
}
