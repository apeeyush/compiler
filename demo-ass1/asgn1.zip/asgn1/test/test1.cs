using System;
namespace Program
{
	class HelloWorld
	{
		static void Main(string[] args)
		{
			/*my first program in C#*/
			Console.WriteLine("Hello World\n");
			Console.ReadKey();
		}

	}
}
