C# Lexer (Assignment 1)

## Group Members
Jaikishan Rupani			12308
Peeyush Agarwal				12475
Sanil Jain					12616

## How to build and run?
cd asgn1
make
bin/lexer test/test1.cs

## How many test files are available?
We have tested our code extensively using test programs numbered from test1 to test23.

## Important Note
1. Install ply on your system.
	sudo apt-get install python-ply
2. The tokens are displayed on next line.
3. Use 
	python bin/lexer.py test/test1.cs 
   if
	bin/lexer test/test1.cs
   is not working on your system.
